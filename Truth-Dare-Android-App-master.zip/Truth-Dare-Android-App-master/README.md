# Truth-Dare-Android-App
## Android P with Machine Learning Apps By learncodeonline.in
### Assignment 02: Truth Dare Android App

On the click of button "Spin Bottle" bottle will spin with random number of degree.

##### Requirements
- Android Studio
- Support for API 21 and above 

<img src="TruthDareGif.gif" width="350" height="650" />

>Note: Also included Adobe XD file of logo.
